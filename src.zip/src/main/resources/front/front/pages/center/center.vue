<template>
	<view class="content">
		<view :style='{"width":"100%","padding":"0","position":"relative","background":"#fff","height":"100%"}'>
			<view :style='{"padding":"20rpx","margin":"0 0 20rpx 0","flexWrap":"wrap","background":"#e4e6e1","display":"flex","width":"100%","position":"relative","height":"300rpx"}' @tap="onPageTap('../user-info/user-info')" class="header" v-bind:class="{'status':isH5Plus}">
				<view :style='{"padding":"20rpx","margin":"0 auto","alignItems":"center","borderRadius":"40rpx 0 0 40rpx","flexWrap":"wrap","background":"#fff","display":"flex","width":"calc(100% - 160rpx)","position":"relative","height":"100%"}' v-if="tableName=='yonghu'" class="userinfo">
					<view :style='{"padding":"20rpx","borderRadius":"40rpx","flexWrap":"wrap","flexDirection":"column","background":"none","display":"flex","width":"calc(100% - 160rpx)","justifyContent":"center","height":"auto"}' class="info">
						<view :style='{"borderColor":"#ccc","margin":"10rpx","color":"#383428","textAlign":"center","borderWidth":"0 0 6rpx 0","width":"30%","lineHeight":"36rpx","fontSize":"28rpx","borderStyle":"solid","fontWeight":"600"}'>{{user.yonghuzhanghao}}<text v-if="user.vip&& user.vip=='是'">(VIP)</text></view>
						<view :style='{"width":"100%","margin":"0 10rpx","lineHeight":"36rpx","fontSize":"24rpx","color":"#b27252"}' v-if="user.money">余额：{{user.money}}</view>
						<view :style='{"width":"100%","margin":"0 10rpx","lineHeight":"36rpx","fontSize":"24rpx","color":"#b27252"}' v-if="user.jf||user.jf==0">积分：{{user.jf}}</view>
					</view>
				</view>
				<view :style='{"padding":"20rpx","margin":"0 auto","alignItems":"center","borderRadius":"40rpx 0 0 40rpx","flexWrap":"wrap","background":"#fff","display":"flex","width":"calc(100% - 160rpx)","position":"relative","height":"100%"}' v-if="tableName=='huishourenyuan'" class="userinfo">
					<view :style='{"padding":"20rpx","borderRadius":"40rpx","flexWrap":"wrap","flexDirection":"column","background":"none","display":"flex","width":"calc(100% - 160rpx)","justifyContent":"center","height":"auto"}' class="info">
						<view :style='{"borderColor":"#ccc","margin":"10rpx","color":"#383428","textAlign":"center","borderWidth":"0 0 6rpx 0","width":"30%","lineHeight":"36rpx","fontSize":"28rpx","borderStyle":"solid","fontWeight":"600"}'>{{user.huishougonghao}}<text v-if="user.vip&& user.vip=='是'">(VIP)</text></view>
						<view :style='{"width":"100%","margin":"0 10rpx","lineHeight":"36rpx","fontSize":"24rpx","color":"#b27252"}' v-if="user.money">余额：{{user.money}}</view>
						<view :style='{"width":"100%","margin":"0 10rpx","lineHeight":"36rpx","fontSize":"24rpx","color":"#b27252"}' v-if="user.jf||user.jf==0">积分：{{user.jf}}</view>
					</view>
				</view>
				<view :style='{"alignItems":"center","borderRadius":"0 40rpx 40rpx 0","background":"#fff","display":"flex","width":"160rpx","justifyContent":"center","height":"auto"}' class="setting">
					<view :style='{"border":"0","width":"64rpx","lineHeight":"64rpx","fontSize":"64rpx","color":"#666","borderRadius":"0"}' class="cuIcon-settings"></view>
				</view>
			</view>
		
		
			<view :style='{"width":"100%","padding":"0 0 160rpx","flexWrap":"wrap","background":"#fff","display":"flex","height":"auto"}' class="list">

				<block v-for="item in menuList" v-bind:key="item.roleName">
					<block v-if="role==item.roleName" v-bind:key="index" v-for=" (menu,index) in item.backMenu">
						<block v-bind:key="sort" v-for=" (child,sort) in menu.child">
							<view :style='{"width":"100%","margin":"10rpx 0","alignItems":"center","background":"rgba(204, 204, 204,.4)","display":"flex","height":"auto"}' v-if="child.tableName!='yifahuodingdan' && child.tableName!='yituikuandingdan' &&child.tableName!='yiquxiaodingdan' && child.tableName!='weizhifudingdan' && child.tableName!='yizhifudingdan' && child.tableName!='yiwanchengdingdan' && child.tableName!='exampaper' && child.tableName!='examquestion' " @tap="onPageTap('../'+child.tableName+'/list?userid='+user.id+'&menuJump='+child.menuJump)" class="li" hover-class="hover">
								<view v-if="false" :style='{"width":"64rpx","lineHeight":"64rpx","fontSize":"64rpx","color":"rgba(0, 186, 189, 1)"}' :class="child.appFrontIcon"></view>
								<view :style='{"width":"100%","padding":"0 20rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#333","flex":"1"}' class="text">{{child.menu}}</view>
								<view v-if="true" :style='{"width":"28rpx","lineHeight":"28rpx","fontSize":"28rpx","color":"#999"}' class="cuIcon-right"></view>
							</view>
						</block>
					</block>
				</block>

				<view @tap="onPageTap('../shop-order/shop-order')" :style='{"width":"100%","margin":"10rpx 0","alignItems":"center","background":"rgba(204, 204, 204,.4)","display":"flex","height":"auto"}' class="li" hover-class="hover">
					<view v-if="false" :style='{"width":"64rpx","lineHeight":"64rpx","fontSize":"64rpx","color":"rgba(0, 186, 189, 1)"}' class="cuIcon-order"></view>
					<view class="text" :style='{"width":"100%","padding":"0 20rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#333","flex":"1"}'>我的订单</view>
					<view v-if="true" :style='{"width":"28rpx","lineHeight":"28rpx","fontSize":"28rpx","color":"#999"}' class="cuIcon-right"></view>
				</view>

			</view>
		</view>
	</view>
</template>
<script>
	import menu from '@/utils/menu'
	export default {
		data() {
			return {
				isH5Plus: true,
				user: {},
				tableName:'',
				role: '',
				menuList: [],
        iconArr: [
          'cuIcon-same',
          'cuIcon-deliver',
          'cuIcon-evaluate',
          'cuIcon-shop',
          'cuIcon-ticket',
          'cuIcon-cascades',
          'cuIcon-discover',
          'cuIcon-question',
          'cuIcon-pic',
          'cuIcon-filter',
          'cuIcon-footprint',
          'cuIcon-pulldown',
          'cuIcon-pullup',
          'cuIcon-moreandroid',
          'cuIcon-refund',
          'cuIcon-qrcode',
          'cuIcon-remind',
          'cuIcon-profile',
          'cuIcon-home',
          'cuIcon-message',
          'cuIcon-link',
          'cuIcon-lock',
          'cuIcon-unlock',
          'cuIcon-vip',
          'cuIcon-weibo',
          'cuIcon-activity',
          'cuIcon-friendadd',
          'cuIcon-friendfamous',
          'cuIcon-friend',
          'cuIcon-goods',
          'cuIcon-selection'
        ],
			};
		},
		computed: {
			baseUrl() {
				return this.$base.url;
			}
		},
		async onLoad(){
			this.role = uni.getStorageSync("role");
			let table = uni.getStorageSync("nowTable");
			let res = await this.$api.session(table);
			this.user = res.data;
			this.tableName = table;
			let menus = menu.list();
			this.menuList = menus;
		},
		async onShow(){
            uni.removeStorageSync("useridTag");
			this.role = uni.getStorageSync("role");
			let table = uni.getStorageSync("nowTable");
			let res = await this.$api.session(table);
			this.user = res.data;
			this.tableName = table;
			let menus = menu.list();
			this.menuList = menus;
		},
		methods: {
			onPageTap(url) {
                uni.setStorageSync("useridTag",1);
				uni.navigateTo({
					url: url,
					fail: function() {
						uni.switchTab({
							url: url
						});
					}
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.content {
		height: calc(100vh - 94px);
		box-sizing: border-box;
	}
</style>
