﻿const base = {
    url : "http://localhost:8080/springboota1ly5177/"
}
export default base
